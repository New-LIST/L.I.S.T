# L.I.S.T
Bakalárska práca - nový list

a: int = 0


def main() -> None:
    global a
    a = int(input("Zadajte cele cislo M: "))
    a -= int(input("Zadajte cele cislo N: "))
    print(f"Ich compare je {a}")


if __name__ == "__main__":
    main()
